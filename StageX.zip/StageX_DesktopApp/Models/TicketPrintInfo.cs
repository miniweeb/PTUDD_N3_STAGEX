﻿namespace StageX_DesktopApp.Models
{
    public class TicketPrintInfo
    {
        public string SeatLabel { get; set; }
        public decimal Price { get; set; }
        public string TicketCode { get; set; }
    }
}