﻿using System.Windows.Controls;

namespace StageX_DesktopApp.Views
{
    public partial class TicketScanView : UserControl
    {
        public TicketScanView()
        {
            InitializeComponent();
        }
    }
}