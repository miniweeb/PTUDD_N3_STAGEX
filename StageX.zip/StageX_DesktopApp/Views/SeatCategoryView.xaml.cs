﻿using System.Windows.Controls;

namespace StageX_DesktopApp.Views
{
    /// <summary>
    /// Interaction logic for SeatCategoryView.xaml
    /// </summary>
    public partial class SeatCategoryView : UserControl
    {
        public SeatCategoryView()
        {
            InitializeComponent();
        }
    }
}