﻿using System.Windows.Controls;

namespace StageX_DesktopApp.Views
{
    public partial class TheaterSeatView : UserControl
    {
        public TheaterSeatView()
        {
            InitializeComponent();
        }
    }
}