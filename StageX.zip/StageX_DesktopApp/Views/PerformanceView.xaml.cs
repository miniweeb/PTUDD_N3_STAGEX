﻿using System.Windows.Controls; // <--- Thêm dòng này nếu chưa có

namespace StageX_DesktopApp.Views
{
    // Sửa ": Window" thành ": UserControl"
    public partial class PerformanceView : UserControl
    {
        public PerformanceView()
        {
            InitializeComponent();
        }
    }
}