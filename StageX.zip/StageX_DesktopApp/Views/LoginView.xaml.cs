﻿using System.Windows;

namespace StageX_DesktopApp.Views
{
    public partial class LoginView : Window
    {
        public LoginView()
        {
            InitializeComponent();
        }
    }
}