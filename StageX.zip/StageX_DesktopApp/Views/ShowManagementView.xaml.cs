﻿using System.Windows.Controls;

namespace StageX_DesktopApp.Views
{
    public partial class ShowManagementView : UserControl
    {
        public ShowManagementView()
        {
            InitializeComponent();
        }
    }
}