﻿using System.Windows.Controls;

namespace StageX_DesktopApp.Views
{
    public partial class ProfileView : UserControl
    {
        public ProfileView()
        {
            InitializeComponent();
        }
    }
}