﻿using System.Windows.Controls;

namespace StageX_DesktopApp.Views
{
    /// <summary>
    /// Interaction logic for ActorManagementView.xaml
    /// </summary>
    public partial class ActorManagementView : UserControl
    {
        public ActorManagementView()
        {
            InitializeComponent();
            // Không cần code xử lý gì ở đây nữa.
            // DataContext đã được khai báo trong file .xaml rồi.
        }
    }
}