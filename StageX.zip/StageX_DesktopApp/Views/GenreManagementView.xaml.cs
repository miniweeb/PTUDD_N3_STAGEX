﻿using System.Windows.Controls;

namespace StageX_DesktopApp.Views // Phải đúng Namespace này
{
    public partial class GenreManagementView : UserControl
    {
        public GenreManagementView()
        {
            InitializeComponent();
        }
    }
}