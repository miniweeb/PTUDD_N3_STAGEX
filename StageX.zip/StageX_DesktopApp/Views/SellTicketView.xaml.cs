using System.Windows.Controls;

namespace StageX_DesktopApp.Views
{
    public partial class SellTicketView : UserControl
    {
        public SellTicketView()
        {
            InitializeComponent();
        }
    }
}